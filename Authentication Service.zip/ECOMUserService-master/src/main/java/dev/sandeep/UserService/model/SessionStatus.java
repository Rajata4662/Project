package dev.sandeep.UserService.model;

public enum SessionStatus {
    ACTIVE,
    ENDED,
}
